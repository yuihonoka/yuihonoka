# YUI's Little Universe — 無料プロフィールリンクページ

## 使い方
1. `index.html` を GitHub の公開リポジトリにアップロードします。
2. GitHub でリポジトリの **Settings → Pages** を開きます。
3. **Build and deployment** の Source を `Deploy from a branch` にします。
4. Branch を `main`、フォルダを `/ (root)` にして Save します。
5. 数分後、Pages 画面に表示される URL で公開ページを確認します。

## 変更する場所
- ニックネーム：`<h1 id="profileName">YUI ✧ ゆい</h1>`
- 用户名：`<div class="handle">@your_username</div>`
- 自我介绍：`<p class="bio">...</p>`
- 头像：搜索 `src="https://placehold.co/` 并替换成图片 URL。也可以在仓库中新建 `images` 文件夹，上传 `avatar.jpg`，然后写成 `src="images/avatar.jpg"`。
- 社交链接：修改每个 `<a class="link-button" href="...">` 的 URL 和显示文字。
- Spotify：将 `https://open.spotify.com/` 替换为你的播放列表或歌曲链接。
- 邮箱：将 `hello@example.com` 替换成你愿意公开的邮箱，或删除 MESSAGE 区块。
- 背景图片：在 CSS 的 `body::before` 中添加 `background-image: url('images/background.jpg');`，并把图片上传到仓库的 `images` 文件夹。

## 注意
- GitHub Pages 免费托管通常需要公开仓库；请勿放入密码、私人资料或不想公开的文件。
- 平台不强制要求在页面放置 GitHub 品牌标识。本页面没有第三方水印。
- 自定义域名需要你另行拥有域名；不购买域名也能用 GitHub 提供的免费地址。
