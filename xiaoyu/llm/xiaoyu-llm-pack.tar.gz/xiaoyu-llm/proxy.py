#!/usr/bin/env python3
# 小鱼本地模型代理：127.0.0.1:7806 (OpenAI 兼容) -> llama-server 127.0.0.1:7807
# 按需启动 llama-server，空闲 10 分钟自动关闭省内存；把长人设换成短人设，只留最近几句。
import json, os, re, subprocess, threading, time, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
D = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(D, "bin")
MODEL = os.path.join(D, "model.gguf")
UP = "http://127.0.0.1:7807"
IDLE = int(os.environ.get("XY_LLM_IDLE", "600"))
THREADS = os.environ.get("XY_LLM_THREADS", "4")
KEEP = 6
PERSONA = open(os.path.join(D, "persona_short.txt"), encoding="utf-8").read().strip()
lock = threading.Lock(); proc = None; last = time.time()

def alive():
    try:
        with urllib.request.urlopen(UP + "/v1/models", timeout=2) as r:
            return r.status == 200 and bool(json.loads(r.read()).get("data"))
    except Exception: return False

def ensure():
    global proc
    with lock:
        if alive(): return True
        if not (proc and proc.poll() is None):
            env = dict(os.environ, LD_LIBRARY_PATH=BIN)
            log = open(os.path.join(D, "llama.log"), "ab")
            proc = subprocess.Popen([os.path.join(BIN, "llama-server"), "-m", MODEL, "--host", "127.0.0.1", "--port", "7807",
                "-c", "2048", "-t", THREADS, "-np", "1", "--alias", "qwen3-0.6b", "--jinja", "--reasoning-budget", "0", "--no-webui"],
                env=env, stdout=log, stderr=log, start_new_session=True)
        for _ in range(600):
            if alive(): return True
            if proc.poll() is not None: return False
            time.sleep(0.5)
        return False

def reaper():
    global proc
    while True:
        time.sleep(30)
        with lock:
            if proc and proc.poll() is None and time.time() - last > IDLE:
                proc.terminate()
                try: proc.wait(10)
                except Exception: proc.kill()
                proc = None

def text_of(c):
    if isinstance(c, str): return c
    if isinstance(c, list): return "".join(p.get("text", "") for p in c if isinstance(p, dict) and p.get("type") == "text")
    return ""

def slim(body):
    msgs = [m for m in body.get("messages", []) if m.get("role") in ("user", "assistant")]
    out = []
    for m in msgs[-KEEP:]:
        t = text_of(m.get("content"))[-800:]
        if t.strip(): out.append({"role": m["role"], "content": t})
    if not out or out[0]["role"] != "user":
        while out and out[0]["role"] != "user": out.pop(0)
    nb = {"model": "qwen3-0.6b", "messages": [{"role": "system", "content": PERSONA}] + out,
          "stream": bool(body.get("stream")), "temperature": body.get("temperature", 0.8),
          "max_tokens": min(int(body.get("max_tokens") or 256), 256),
          "chat_template_kwargs": {"enable_thinking": False}}
    return nb

THINK = re.compile(r"<think>.*?</think>\s*", re.S)

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def _send(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.rstrip("/").endswith("/models"):
            return self._send(200, {"object": "list", "data": [{"id": "qwen3-0.6b", "object": "model", "owned_by": "local"}]})
        return self._send(200, {"ok": True, "llama_running": alive()})
    def do_POST(self):
        global last
        n = int(self.headers.get("Content-Length") or 0)
        try: body = json.loads(self.rfile.read(n) or b"{}")
        except Exception: return self._send(400, {"error": {"message": "bad json"}})
        if not self.path.rstrip("/").endswith("/chat/completions"):
            return self._send(404, {"error": {"message": "only chat/completions"}})
        last = time.time()
        if not ensure(): return self._send(503, {"error": {"message": "local llama failed to start, see llama.log"}})
        nb = slim(body)
        req = urllib.request.Request(UP + "/v1/chat/completions", data=json.dumps(nb).encode(), headers={"Content-Type": "application/json"})
        r = None
        for _ in range(60):
            try:
                r = urllib.request.urlopen(req, timeout=600); break
            except urllib.error.HTTPError as e:
                if e.code in (404, 503): time.sleep(1); continue
                return self._send(502, {"error": {"message": str(e)}})
            except Exception as e:
                return self._send(502, {"error": {"message": str(e)}})
        if r is None: return self._send(503, {"error": {"message": "local model still loading"}})
        if nb["stream"]:
            self.send_response(200); self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache"); self.send_header("Connection", "close"); self.end_headers()
            try:
                for line in r:
                    self.wfile.write(line); self.wfile.flush()
            except Exception: pass
            self.close_connection = True
        else:
            d = json.loads(r.read())
            for ch in d.get("choices", []):
                m = ch.get("message") or {}
                if isinstance(m.get("content"), str): m["content"] = THINK.sub("", m["content"]).strip()
                m.pop("reasoning_content", None)
            self._send(200, d)
        last = time.time()

if __name__ == "__main__":
    threading.Thread(target=reaper, daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1", 7806), H).serve_forever()
