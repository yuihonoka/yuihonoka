#!/bin/bash
# 小鱼本地模型：bash /persistent/xiaoyu-llm/llm.sh start|stop|status|test
D=/persistent/xiaoyu-llm
PY=/opt/astrbot-venv/bin/python; [ -x "$PY" ] || PY=python3
case "${1:-status}" in
  start) pgrep -f "$D/proxy.py" >/dev/null && { echo "已在运行"; exit 0; }
         setsid "$PY" "$D/proxy.py" >> "$D/proxy.log" 2>&1 < /dev/null & sleep 1; echo "已启动（端口 7806，模型第一次被叫时才加载）";;
  stop)  pkill -f "$D/proxy.py"; pkill -f "$D/bin/llama-server"; echo "已停止";;
  status) pgrep -af "$D/proxy.py" >/dev/null && echo "代理：运行中" || echo "代理：未运行"
          pgrep -af "$D/bin/llama-server" >/dev/null && echo "模型：已加载" || echo "模型：未加载（空闲时自动卸载）";;
  test)  bash "$0" start >/dev/null; echo "问小鱼一句（第一次要加载，约半分钟到两分钟）…"
         time curl -s -m 600 http://127.0.0.1:7806/v1/chat/completions -H 'Content-Type: application/json' \
           -d '{"messages":[{"role":"user","content":"小鱼，跟爸比打个招呼"}]}' | "$PY" -c "import json,sys;print(json.load(sys.stdin)['choices'][0]['message']['content'])";;
esac
