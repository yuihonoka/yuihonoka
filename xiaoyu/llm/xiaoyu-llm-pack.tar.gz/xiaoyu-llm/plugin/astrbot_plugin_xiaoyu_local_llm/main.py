import os, subprocess
from astrbot.api.star import Context, Star, register
from astrbot.api import logger

SH = "/persistent/xiaoyu-llm/llm.sh"

@register("astrbot_plugin_xiaoyu_local_llm", "hark", "启动手机本地小模型代理", "0.1")
class XiaoyuLocalLLM(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        if os.path.exists(SH):
            try:
                subprocess.Popen(["bash", SH, "start"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
                logger.info("[xiaoyu_local_llm] 本地模型代理已拉起 :7806")
            except Exception as e:
                logger.warning(f"[xiaoyu_local_llm] 启动失败: {e}")
